/*
 * main implementation: use this 'C' sample to create your own application
 */
#include <stdio.h>
#include "derivative.h" /* include peripheral declarations */

#define GPIO_PIN_MASK            0x1Fu
#define GPIO_PIN(x)              (((1)<<(x & GPIO_PIN_MASK)))

int main(void)
{
	int counter = 0;
	
	// Turn on all port clocks
		SIM_SCGC5 = SIM_SCGC5_PORTA_MASK | SIM_SCGC5_PORTB_MASK | SIM_SCGC5_PORTC_MASK | SIM_SCGC5_PORTD_MASK | SIM_SCGC5_PORTE_MASK;

	// Set PTA10, PTA11, PTA 19, PTA28, PTA29 and PTE26 for GPIO functionality
		PORTA_PCR10 = (0|PORT_PCR_MUX(1));
		PORTA_PCR11 = (0|PORT_PCR_MUX(1));
		PORTA_PCR28 = (0|PORT_PCR_MUX(1));
		PORTA_PCR29 = (0|PORT_PCR_MUX(1));
		PORTA_PCR19 = (0|PORT_PCR_MUX(1));
		PORTE_PCR26 = (0|PORT_PCR_MUX(1));

	// Change PTA10, PTA11, PTA28, PTA29 to outputs
	    GPIOA_PDDR = GPIO_PDDR_PDD(GPIO_PIN(10) | GPIO_PIN(11) | GPIO_PIN(28) | GPIO_PIN(29) );
	    
	// Set PTA19, PTE26 to inputs    
	    GPIOA_PDDR &= ~GPIO_PDDR_PDD(GPIO_PIN(19));
	    GPIOE_PDDR &= ~GPIO_PDDR_PDD(GPIO_PIN(26));
	
	// Pullup einschalten
		PORTA_PCR19 |= PORT_PCR_PS_MASK;
		PORTE_PCR26 |= PORT_PCR_PS_MASK;
	    PORTA_PCR19 |= PORT_PCR_PE_MASK;
		PORTE_PCR26 |= PORT_PCR_PE_MASK;
	    
	// alle LEDs am Anfang ausschalten
	    GPIOA_PDOR |= GPIO_PDOR_PDO(GPIO_PIN(11));   		// orange LED aus
	    GPIOA_PDOR |= GPIO_PDOR_PDO(GPIO_PIN(28));   		// gelbe LED aus
	    GPIOA_PDOR |= GPIO_PDOR_PDO(GPIO_PIN(29));   		// gr�ne LED aus
	    GPIOA_PDOR |= GPIO_PDOR_PDO(GPIO_PIN(10));   		// blaue LED aus

		for(;;) {	   							 		 	// Endlosschleife
	    
		if (!(GPIOA_PDIR & (GPIO_PIN(19))))	 		 	 	// Bit nicht gesetzt, Taster SW1 an
		{
			GPIOA_PDOR ^= GPIO_PDOR_PDO(GPIO_PIN(11));   	// orange LED umschalten
			GPIOA_PDOR ^= GPIO_PDOR_PDO(GPIO_PIN(28));   	// gelbe LED umschalten
			for (counter = 0; counter < 10000; counter++);  // kurz warten
		}
		
		if (!(GPIOE_PDIR & (GPIO_PIN(26))))	 		 	 	// Bit nicht gesetzt, Taster SW2 an
		{
			GPIOA_PDOR ^= GPIO_PDOR_PDO(GPIO_PIN(29));   	// gr�ne LED umschalten
			GPIOA_PDOR ^= GPIO_PDOR_PDO(GPIO_PIN(10));   	// blaue LED umschalten
			for (counter = 0; counter < 10000; counter++);  // kurz warten
		}

		}											 		// Ende der Schleife
		
	return 0;
}
