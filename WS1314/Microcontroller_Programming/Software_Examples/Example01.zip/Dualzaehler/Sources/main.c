#include <stdio.h>
#include "derivative.h" /* include peripheral declarations */
#include "dsp.h"  // just for the dsp capabilities..such as u32.
#include "adc16.h"     // ADC driver defines

#define GPIO_PIN_MASK            0x1Fu
#define GPIO_PIN(x)              (((1)<<(x & GPIO_PIN_MASK)))
#define EnableInterrupts 		asm(" CPSIE i");

#define ADC1_CHANA    20   // set to desired ADC1 channel trigger A  20 defaults to potentiometer in TWRK60     
#define ADC1_CHANB    20   // set to desired ADC1 channel trigger B
#define ADC1A_DONE   0x04       
#define ADC1B_DONE   0x08   
#define VECTOR_074      adc1_isr     // 0x0000_0128 74     58     ADC1
// Global filtered output for ADC1 used by ISR and by demo code print routine
extern u32 exponentially_filtered_result1 = 0;
tADC_Config Master_Adc_Config;
volatile static unsigned adc1A,adc1B;

//Function declarations
void porta_isr(void);
void porte_isr(void);
void delay(void);
void disable_wdog(void);
void enable_irq(int);
void pit0_isr(void);
void pit1_isr(void);
void adc1_isr(void);  

// Globals
int updown = 1;
int counter = 0;
uint pit1_lv = 0x02000000; // Initial Load Value for PIT#1
uint pit1_min = 0x200000;

// MAIN
void main(void)
  {
	/*
	 * SW1 = PTA19
	 * SW2 = PTE26
	 * LED1(or) = PTA11
	 * LED2(ge) = PTA28
	 * LED3(gn) = PTA29
	 * LED4(bl) = PTA10
	 * Poti = ADC1_DM1
	 */

	int led1, led2, led3, led4;

//	disable_wdog(); // wird schon in kinetis_sysinit gemacht
	
/* Turn on all port clocks */
	SIM_SCGC5 = SIM_SCGC5_PORTA_MASK | SIM_SCGC5_PORTB_MASK | SIM_SCGC5_PORTC_MASK | SIM_SCGC5_PORTD_MASK | SIM_SCGC5_PORTE_MASK;

//Set PTA10, PTA11, PTA28, and PTA29 (connected to LED's) for GPIO functionality
	PORTA_PCR10=(0|PORT_PCR_MUX(1));
	PORTA_PCR11=(0|PORT_PCR_MUX(1));
	PORTA_PCR28=(0|PORT_PCR_MUX(1));
	PORTA_PCR29=(0|PORT_PCR_MUX(1));

//Change PTA10, PTA11, PTA28, PTA29 to outputs
    GPIOA_PDDR=GPIO_PDDR_PDD(GPIO_PIN(10) | GPIO_PIN(11) | GPIO_PIN(28) | GPIO_PIN(29) );	
	
// Set PTA19 and PTE26 (connected to SW1 and SW2) for GPIO functionality, falling IRQ,
//   and to use internal pull-ups. (pin defaults to input state)
    PORTA_PCR19=PORT_PCR_MUX(1)|PORT_PCR_IRQC(0xA)|PORT_PCR_PE_MASK|PORT_PCR_PS_MASK;
    PORTE_PCR26=PORT_PCR_MUX(1)|PORT_PCR_IRQC(0xA)|PORT_PCR_PE_MASK|PORT_PCR_PS_MASK;
	
/* Enable GPIOA and GPIOE interrupts in NVIC */
   	enable_irq(87); //GPIOA Vector is 103. IRQ# is 103-16=87
   	enable_irq(91); //GPIOE Vector is 107. IRQ# is 107-16=91

/* Enable the clock to the PIT module */
    SIM_SCGC6 |= SIM_SCGC6_PIT_MASK;
// turn on PIT
//   	PIT_MCR = 0x01; // Debug Modus
   	PIT_MCR = 0x0; // Run Modus
// Timer 1 (Z�hler)
   	PIT_LDVAL1 = pit1_lv; // setup timer (~1s)
   	PIT_TCTRL1 |= 1; // start Timer 1 (TEN)
   	PIT_TFLG1 |= 1;  // clear pending IRQ (TIF)
   	PIT_TCTRL1 |= 2;	//IRQ enable (TIE)
   	enable_irq(69); // PIT #1

// Enable ADC1 Clock   	
    SIM_SCGC3 |= (SIM_SCGC3_ADC1_MASK );
// Configure ADC
    SIM_SOPT7 = SIM_SOPT7_ADC1ALTTRGEN_MASK | SIM_SOPT7_ADC1TRGSEL(4);	//ADC1 duch PIT0 triggern      
// setup the initial ADC default configuration
    Master_Adc_Config.CONFIG1  = ADLPC_NORMAL
                               | ADC_CFG1_ADIV(ADIV_4)
                               | ADLSMP_LONG
                               | ADC_CFG1_MODE(MODE_16)
                               | ADC_CFG1_ADICLK(ADICLK_BUS);
    Master_Adc_Config.CONFIG2  = MUXSEL_ADCA
                               | ADACKEN_DISABLED
                               | ADHSC_HISPEED
                               | ADC_CFG2_ADLSTS(ADLSTS_20) ;
    Master_Adc_Config.COMPARE1 = 0x1234u ;                 // can be anything
    Master_Adc_Config.COMPARE2 = 0x5678u ;                 // can be anything
                                                           // since not using compare feature
    Master_Adc_Config.STATUS2  = ADTRG_HW
                               | ACFE_DISABLED
                               | ACFGT_GREATER
                               | ACREN_ENABLED
                               | DMAEN_DISABLED
                               | ADC_SC2_REFSEL(REFSEL_EXT);

    Master_Adc_Config.STATUS3  = CAL_OFF
                               | ADCO_SINGLE
                               | AVGE_ENABLED
                               | ADC_SC3_AVGS(AVGS_32);

    Master_Adc_Config.PGA      = PGAEN_DISABLED
                               | PGACHP_NOCHOP
                               | PGALP_NORMAL
                               | ADC_PGA_PGAG(PGAG_64);
    Master_Adc_Config.STATUS1A = AIEN_OFF | DIFF_SINGLE | ADC_SC1_ADCH(31);
    Master_Adc_Config.STATUS1B = AIEN_OFF | DIFF_SINGLE | ADC_SC1_ADCH(31);
    // Write Configuration for ADC1:
    ADC_Config_Alt(ADC1_BASE_PTR, &Master_Adc_Config);  // config ADC
    ADC_Cal(ADC1_BASE_PTR);                             // do the calibration
    // The structure still has the desired configuration.  So restore it.
    // Why restore it?  The calibration makes some adjustments to the
    // configuration of the ADC.  The are now undone:

    // config the ADC again to default conditions
    ADC_Config_Alt(ADC1_BASE_PTR, &Master_Adc_Config);

    // use interrupts, single ended mode, and real channel numbers now:
    Master_Adc_Config.STATUS1A = AIEN_ON | DIFF_SINGLE | ADC_SC1_ADCH(ADC1_CHANA);
    Master_Adc_Config.STATUS1B = AIEN_ON | DIFF_SINGLE | ADC_SC1_ADCH(ADC1_CHANB);
    ADC_Config_Alt(ADC1_BASE_PTR, &Master_Adc_Config);  // config ADC1
    // ADC1_CHANA POT channel set the same as the following for demo: 20
    // ADC1_CHANB POT channel set the same as the above for demo: 20
    enable_irq(58) ;   // ready for this interrupt.

// Timer 0 (ADC)
   	PIT_LDVAL0 = 0xC350; // setup timer (~1ms) 
   	PIT_TCTRL0 |= 1; // start Timer 1 (TEN)
   	PIT_TFLG0 |= 1;  // clear pending IRQ (TIF)
   	PIT_TCTRL0 |= 2;	//IRQ enable (TIE)
  	enable_irq(68); // PIT #0

	EnableInterrupts;
    	
	printf("Dualz�hler mit Interruptsteuerung \n\r");
    printf("count up \n");

    for(;;) {	   
	   	led1 = counter & 1;
	   	led2 = counter & 2;
	   	led3 = counter & 4;
	   	led4 = counter & 8;
        
	   	if (led1 == 1)
	   	    //Set PTA11 to 0 (turns on orange LED)
	   	    GPIOA_PDOR &= ~GPIO_PDOR_PDO(GPIO_PIN(11));
  		else
	   	    GPIOA_PDOR |= GPIO_PDOR_PDO(GPIO_PIN(11));
	   	if (led2 == 2)
	   	    //Set PTA28 to 0 (turns on yellow LED)
	   	    GPIOA_PDOR &= ~GPIO_PDOR_PDO(GPIO_PIN(28));
   		else
	   	    GPIOA_PDOR |= GPIO_PDOR_PDO(GPIO_PIN(28));
	   	if (led3 == 4)
	   	    //Set PTA29 to 0 (turns on green LED)
	   	    GPIOA_PDOR &= ~GPIO_PDOR_PDO(GPIO_PIN(29));
   		else
	   	    GPIOA_PDOR |= GPIO_PDOR_PDO(GPIO_PIN(29));
	   	if (led4 == 8)
	   	    //Set PTA10 to 0 (turns on blue LED)
	   	    GPIOA_PDOR &= ~GPIO_PDOR_PDO(GPIO_PIN(10));
   		else
	   	    GPIOA_PDOR |= GPIO_PDOR_PDO(GPIO_PIN(10));
	}
	for(;;)	//Endlosschleife, sollte nicht erreicht werden!
		{}
}

/********************************************************************/
/*
 * ISR for PORTA interrupts
 */
void porta_isr(void)
{
  PORTA_ISFR=0xFFFFFFFF;  //Clear Port A ISR flags
  PIT_LDVAL1 = PIT_LDVAL1 << 1;
  printf("count up\n",PIT_LDVAL1);
  updown = 1;
}

/*
 * ISR for PORTE interrupts
 */
void porte_isr(void)
{
  PORTE_ISFR=0xFFFFFFFF;  //Clear Port E ISR flags
  PIT_LDVAL1 = PIT_LDVAL1 >> 1;
  printf("count down\n",PIT_LDVAL1);
  updown = 0;
}

void pit0_isr(void)
{
	int	temp;
	
	PIT_TFLG0 |= 1; // clear IRQ (TIF)
	temp = PIT_LDVAL0;
}

void pit1_isr(void)
{
	int	temp;
	
	PIT_TFLG1 |= 1; // clear IRQ (TIF)
	temp = PIT_LDVAL1;
    if (updown == 1)
    	counter++;
    else
    	counter--;
 
}

/******************************************************************************
* adc1_isr(void)
*
* use to signal ADC1 end of conversion
* In:  n/a
* Out: exponentially filtered potentiometer reading!
* The ADC1 is used to sample the potentiometer on the A side and the B side:
* ping-pong.  That reading is filtered for an aggregate of ADC1 readings: exponentially_filtered_result1
* thus the filtered POT output is available for display.
******************************************************************************/
void adc1_isr(void)
{
uint temp;

  if (( ADC1_SC1A & ADC_SC1_COCO_MASK ) == ADC_SC1_COCO_MASK) {  // check which of the two conversions just triggered
    adc1A = ADC1_RA;           // this will clear the COCO bit that is also the interrupt flag

    // Begin exponential filter code for Potentiometer setting for demonstration of filter effect
    exponentially_filtered_result1 += adc1A;
    exponentially_filtered_result1 /= 2 ;
    // Spikes are attenuated 6dB, 12dB, 24dB, .. and so on until they die out.
    // End exponential filter code..  add f*sample, divide by (f+1).. f is 1 for this case.
    }
  else if (( ADC1_SC1B & ADC_SC1_COCO_MASK ) == ADC_SC1_COCO_MASK) {
    adc1B = ADC1_RB;

    // Begin exponential filter code for Potentiometer setting for demonstration of filter effect
    exponentially_filtered_result1 += adc1B;
    exponentially_filtered_result1 /= 2 ;
    // Spikes are attenuated 6dB, 12dB, 24dB, .. and so on until they die out.
    // End exponential filter code..  add f*sample, divide by (f+1).. f is 1 for this case.
    }
  
//  printf("R1A=%6d  R1B=%6d   POT=%6d\r",adc1A,adc1B, exponentially_filtered_result1);
	temp = ((double) exponentially_filtered_result1) / 0x1000;
	PIT_LDVAL1 = pit1_lv - ((15 - temp) * (pit1_lv >> 4));
	return;
}

void enable_irq (int irq)
{
    int div;
    
    // Make sure that the IRQ is an allowable number. Right now up to 91 is used.
    if (irq > 91)
        printf("\nERR! Invalid IRQ value passed to enable irq function!\n");
    
    /* Determine which of the NVICISERs corresponds to the irq */
    div = irq/32;
    
    switch (div)
    {
    	case 0x0:
              NVICICPR0 |= 1 << (irq%32);
              NVICISER0 |= 1 << (irq%32);
              break;
    	case 0x1:
              NVICICPR1 |= 1 << (irq%32);
              NVICISER1 |= 1 << (irq%32);
              break;
    	case 0x2:
              NVICICPR2 |= 1 << (irq%32);
              NVICISER2 |= 1 << (irq%32);
              break;
    }              
}

/*
void disable_wdog(void)
{
	// disable all interrupts
	asm("CPSID i");
	// Write 0xC520 to the unlock register 
	WDOG_UNLOCK = 0xC520;
	// Followed by 0xD928 to complete the unlock 
	WDOG_UNLOCK = 0xD928;
	// enable all interrupts 
	asm("CPSIE i");
	// Clear the WDOGEN bit to disable the watch dog 
	WDOG_STCTRLH &= ~WDOG_STCTRLH_WDOGEN_MASK;
}
*/
