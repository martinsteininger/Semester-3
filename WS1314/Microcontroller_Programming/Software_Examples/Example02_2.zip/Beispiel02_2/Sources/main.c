/*
 * main implementation: use this 'C' sample to create your own application
 */
//#include <stdio.h>
#include "derivative.h" /* include peripheral declarations */

#define GPIO_PIN_MASK            0x1Fu
#define GPIO_PIN(x)              (((1)<<(x & GPIO_PIN_MASK)))

int warten (void);
int counter = 0;

int main(void)
{

	// Turn on all port clocks
		SIM_SCGC5 = SIM_SCGC5_PORTA_MASK | SIM_SCGC5_PORTB_MASK | SIM_SCGC5_PORTC_MASK | SIM_SCGC5_PORTD_MASK | SIM_SCGC5_PORTE_MASK;

	// Set PTA10, PTA11, PTA28, and PTA29 (connected to LED's) for GPIO functionality
		PORTA_PCR10=(0|PORT_PCR_MUX(1));
		PORTA_PCR11=(0|PORT_PCR_MUX(1));
		PORTA_PCR28=(0|PORT_PCR_MUX(1));
		PORTA_PCR29=(0|PORT_PCR_MUX(1));

	// Change PTA10, PTA11, PTA28, PTA29 to outputs
	    GPIOA_PDDR=GPIO_PDDR_PDD(GPIO_PIN(10) | GPIO_PIN(11) | GPIO_PIN(28) | GPIO_PIN(29) );	
	
	// alle LEDs am Anfang ausschalten
	    GPIOA_PDOR |= GPIO_PDOR_PDO(GPIO_PIN(11));   // orange LED aus
	    GPIOA_PDOR |= GPIO_PDOR_PDO(GPIO_PIN(28));   // gelbe LED aus
	    GPIOA_PDOR |= GPIO_PDOR_PDO(GPIO_PIN(29));   // gr�ne LED aus
	    GPIOA_PDOR |= GPIO_PDOR_PDO(GPIO_PIN(10));   // blaue LED aus

		for(;;) {	   							 	 // Endlosschleife
	    
   	    // Set PTA11 to 0 (turns on orange LED)
   	    GPIOA_PDOR &= ~GPIO_PDOR_PDO(GPIO_PIN(11));  // orange LED an
        // printf("LED orange\n\r");
   	    warten();  											
   	    GPIOA_PDOR |= GPIO_PDOR_PDO(GPIO_PIN(11));   // orange LED aus

   	    // Set PTA28 to 0 (turns on yellow LED)
   	    GPIOA_PDOR &= ~GPIO_PDOR_PDO(GPIO_PIN(28));  // gelbe LED an
   	    // printf("LED gelb\n\r");
   	    warten();
   	    GPIOA_PDOR |= GPIO_PDOR_PDO(GPIO_PIN(28));   // gelbe LED aus

   	    // Set PTA29 to 0 (turns on green LED)
   	    GPIOA_PDOR &= ~GPIO_PDOR_PDO(GPIO_PIN(29));  // gr�ne LED an
   	    // printf("LED gr�n\n\r");
   	    warten();
   	    GPIOA_PDOR |= GPIO_PDOR_PDO(GPIO_PIN(29));   // gr�ne LED aus

   	    // Set PTA10 to 0 (turns on blue LED)
   	    GPIOA_PDOR &= ~GPIO_PDOR_PDO(GPIO_PIN(10));  // blaue LED an
   	    // printf("LED blau\n\r");
   	    warten();
   	    GPIOA_PDOR |= GPIO_PDOR_PDO(GPIO_PIN(10));   // blaue LED aus

   	    // Set PTA29 to 0 (turns on green LED)
   	    GPIOA_PDOR &= ~GPIO_PDOR_PDO(GPIO_PIN(29));  // gr�ne LED an
   	    // printf("LED gr�n\n\r");
   	    warten();
   	    GPIOA_PDOR |= GPIO_PDOR_PDO(GPIO_PIN(29));   // gr�ne LED aus

   	    // Set PTA28 to 0 (turns on yellow LED)
   	    GPIOA_PDOR &= ~GPIO_PDOR_PDO(GPIO_PIN(28));  // gelbe LED an
   	    // printf("LED gelb\n\r");
   	    warten();
   	    GPIOA_PDOR |= GPIO_PDOR_PDO(GPIO_PIN(28));   // gelbe LED aus

		}											 // Ende der Schleife

	return 0;
}

int warten (void)
	{
	for (counter = 0; counter < 1000000; counter++);
	}


